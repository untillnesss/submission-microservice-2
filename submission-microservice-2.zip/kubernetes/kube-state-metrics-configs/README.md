# kube-state-metrics-configs
Kube state metrics kubernetes deployment configs
